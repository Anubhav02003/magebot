from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel
import openai
import base64
import io
from PIL import Image
import json
import asyncio
from typing import List, Dict, Any
import os

app = FastAPI()

# Serve static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Configure OpenAI with your API key
openai.api_key = "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"

# Store conversation history and uploaded images
conversations: Dict[str, List[Dict[str, Any]]] = {}
uploaded_images: Dict[str, str] = {}

class ChatMessage(BaseModel):
    session_id: str
    message: str

class ChatResponse(BaseModel):
    response: str
    session_id: str

def encode_image(image_file):
    """Convert uploaded image to base64 for OpenAI API"""
    image = Image.open(image_file)
    # Resize image if too large
    if image.width > 1024 or image.height > 1024:
        image.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
    
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG")
    return base64.b64encode(buffer.getvalue()).decode('utf-8')

@app.get("/", response_class=HTMLResponse)
async def get_landing_page():
    """Serve the landing page"""
    with open("static/landing.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.get("/chat", response_class=HTMLResponse)
async def get_chat_interface():
    """Serve the main chat interface"""
    with open("static/chat.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.get("/about", response_class=HTMLResponse)
async def get_about_page():
    """Serve the about page"""
    with open("static/about.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.post("/upload-image")
async def upload_image(session_id: str, file: UploadFile = File(...)):
    """Handle image upload"""
    try:
        # Validate file type
        if not file.content_type.startswith("image/"):
            raise HTTPException(status_code=400, detail="File must be an image")
        
        # Encode image
        image_base64 = encode_image(file.file)
        uploaded_images[session_id] = image_base64
        
        # Initialize conversation for this session
        if session_id not in conversations:
            conversations[session_id] = []
        
        return {"message": "Image uploaded successfully", "session_id": session_id}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing image: {str(e)}")

@app.post("/chat-message")
async def chat_with_image(chat_message: ChatMessage):
    """Handle chat messages about the uploaded image"""
    try:
        session_id = chat_message.session_id
        user_message = chat_message.message
        
        # Check if image exists for this session
        if session_id not in uploaded_images:
            raise HTTPException(status_code=400, detail="No image uploaded for this session")
        
        # Get conversation history
        if session_id not in conversations:
            conversations[session_id] = []
        
        # Add user message to conversation
        conversations[session_id].append({
            "role": "user",
            "content": user_message
        })
        
        # Prepare messages for OpenAI API
        messages = [
            {
                "role": "system",
                "content": "You are a helpful AI assistant that can analyze images and answer questions about them. Be detailed and accurate in your responses."
            }
        ]
        
        # Add the image to the first message if this is the start of conversation
        if len(conversations[session_id]) == 1:
            messages.append({
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": f"I've uploaded an image. Here's my question: {user_message}"
                    },
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{uploaded_images[session_id]}"
                        }
                    }
                ]
            })
        else:
            # Add conversation history
            for msg in conversations[session_id][:-1]:
                messages.append(msg)
            
            # Add current message with reference to the image
            messages.append({
                "role": "user",
                "content": f"Regarding the image I uploaded earlier: {user_message}"
            })
        
        # Call OpenAI API
        response = openai.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=messages,
            max_tokens=500
        )
        
        ai_response = response.choices[0].message.content
        
        # Add AI response to conversation
        conversations[session_id].append({
            "role": "assistant",
            "content": ai_response
        })
        
        return ChatResponse(response=ai_response, session_id=session_id)
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing chat: {str(e)}")

@app.get("/conversation/{session_id}")
async def get_conversation(session_id: str):
    """Get conversation history for a session"""
    if session_id in conversations:
        return {"conversation": conversations[session_id]}
    return {"conversation": []}

@app.delete("/session/{session_id}")
async def clear_session(session_id: str):
    """Clear session data"""
    if session_id in conversations:
        del conversations[session_id]
    if session_id in uploaded_images:
        del uploaded_images[session_id]
    return {"message": "Session cleared"}

@app.get("/preview", response_class=HTMLResponse)
async def get_preview_page():
    """Serve the preview page"""
    with open("static/preview.html", "r") as f:
        return HTMLResponse(content=f.read())

@app.get("/app", response_class=HTMLResponse)
async def get_app_page():
    """Serve the app page"""
    with open("static/app.html", "r") as f:
        return HTMLResponse(content=f.read())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
