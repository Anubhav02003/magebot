class ImageChatbot {
  constructor() {
    this.sessionId = this.generateSessionId()
    this.imageUploaded = false
    this.initializeEventListeners()
  }

  generateSessionId() {
    return "session_" + Math.random().toString(36).substr(2, 9)
  }

  initializeEventListeners() {
    const fileInput = document.getElementById("fileInput")
    const uploadArea = document.getElementById("uploadArea")
    const messageInput = document.getElementById("messageInput")
    const sendBtn = document.getElementById("sendBtn")

    // File input change
    fileInput.addEventListener("change", (e) => {
      if (e.target.files.length > 0) {
        this.uploadImage(e.target.files[0])
      }
    })

    // Drag and drop
    uploadArea.addEventListener("dragover", (e) => {
      e.preventDefault()
      uploadArea.classList.add("dragover")
    })

    uploadArea.addEventListener("dragleave", () => {
      uploadArea.classList.remove("dragover")
    })

    uploadArea.addEventListener("drop", (e) => {
      e.preventDefault()
      uploadArea.classList.remove("dragover")

      const files = e.dataTransfer.files
      if (files.length > 0 && files[0].type.startsWith("image/")) {
        this.uploadImage(files[0])
      }
    })

    // Message input
    messageInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault()
        this.sendMessage()
      }
    })

    // Send button
    sendBtn.addEventListener("click", () => this.sendMessage())
  }

  async uploadImage(file) {
    const formData = new FormData()
    formData.append("file", file)
    formData.append("session_id", this.sessionId)

    try {
      this.showLoading(true)

      const response = await fetch("/upload-image", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        const result = await response.json()
        this.imageUploaded = true
        this.enableChat()
        this.showImagePreview(file)
        this.addMessage("ai", "✅ Image uploaded successfully! Now you can ask me questions about it.")
      } else {
        const error = await response.json()
        this.addMessage("ai", `❌ Error uploading image: ${error.detail}`)
      }
    } catch (error) {
      this.addMessage("ai", `❌ Error uploading image: ${error.message}`)
    } finally {
      this.showLoading(false)
    }
  }

  showImagePreview(file) {
    const preview = document.getElementById("imagePreview")
    const reader = new FileReader()

    reader.onload = (e) => {
      preview.innerHTML = `
                <img src="${e.target.result}" alt="Uploaded image" class="uploaded-image">
                <p>Image uploaded successfully!</p>
            `
    }

    reader.readAsDataURL(file)
  }

  enableChat() {
    const messageInput = document.getElementById("messageInput")
    const sendBtn = document.getElementById("sendBtn")

    messageInput.disabled = false
    sendBtn.disabled = false
    messageInput.placeholder = "Ask me about the image..."
    messageInput.focus()
  }

  async sendMessage() {
    const messageInput = document.getElementById("messageInput")
    const message = messageInput.value.trim()

    if (!message || !this.imageUploaded) return

    // Add user message to chat
    this.addMessage("user", message)
    messageInput.value = ""

    try {
      this.showLoading(true)

      const response = await fetch("/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          session_id: this.sessionId,
          message: message,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        this.addMessage("ai", result.response)
      } else {
        const error = await response.json()
        this.addMessage("ai", `❌ Error: ${error.detail}`)
      }
    } catch (error) {
      this.addMessage("ai", `❌ Error: ${error.message}`)
    } finally {
      this.showLoading(false)
    }
  }

  addMessage(sender, content) {
    const messagesContainer = document.getElementById("messages")
    const messageDiv = document.createElement("div")
    messageDiv.className = `message ${sender}`

    const messageContent = document.createElement("div")
    messageContent.className = "message-content"
    messageContent.textContent = content

    messageDiv.appendChild(messageContent)
    messagesContainer.appendChild(messageDiv)

    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight
  }

  showLoading(show) {
    const loading = document.getElementById("loading")
    const sendBtn = document.getElementById("sendBtn")

    loading.style.display = show ? "block" : "none"
    sendBtn.disabled = show
  }

  async clearSession() {
    try {
      await fetch(`/session/${this.sessionId}`, {
        method: "DELETE",
      })

      // Reset the interface
      this.sessionId = this.generateSessionId()
      this.imageUploaded = false

      const messageInput = document.getElementById("messageInput")
      const sendBtn = document.getElementById("sendBtn")
      const imagePreview = document.getElementById("imagePreview")
      const messages = document.getElementById("messages")

      messageInput.disabled = true
      sendBtn.disabled = true
      messageInput.placeholder = "Upload an image first..."
      imagePreview.innerHTML = ""

      // Clear messages except welcome message
      messages.innerHTML = `
                <div class="message ai">
                    <div class="message-content">
                        👋 Hello! Please upload an image first, then ask me any questions about it. I can help you identify objects, describe scenes, read text, and much more!
                    </div>
                </div>
            `
    } catch (error) {
      console.error("Error clearing session:", error)
    }
  }
}

// Global function for clear button
function clearSession() {
  if (window.chatbot) {
    window.chatbot.clearSession()
  }
}

// Initialize the chatbot when the page loads
document.addEventListener("DOMContentLoaded", () => {
  window.chatbot = new ImageChatbot()
})
